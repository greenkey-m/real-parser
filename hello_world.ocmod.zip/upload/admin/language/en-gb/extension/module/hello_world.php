<?php
// Heading
$_['heading_title']    		= 'Hello World';

// Text
$_['text_extension']   		= 'Extensions';
$_['text_success']     		= 'Success: You have modified Hello World module!';
$_['text_edit']        		= 'Edit Hello World Module';

// Entry
$_['entry_id']				= 'ID';
$_['entry_status']     		= 'Status';

// Help

$_['help_id']				= 'Some help string';

// Error
$_['error_permission'] 		= 'Warning: You do not have permission to modify Hello World module!';
$_['error_id']    			= 'ID is required!';